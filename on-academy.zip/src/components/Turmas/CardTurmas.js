import { useNavigation } from '@react-navigation/native';
import React from 'react'
import { TouchableOpacity } from 'react-native'
import { StyleSheet, Text, View } from 'react-native'
import { useTheme } from '../../path/ThemeContext';

export default function CardTurmas({turma, alunos, periodo, numero, navegacao}) {
    const navigation = useNavigation();
     const { isDarkMode } = useTheme();
    return (
        <View style={[styles.card, {backgroundColor: isDarkMode ? '#141414' : '#F0F7FF'}  ]}>
            <View style={styles.linha}>
                <Text style={{ fontWeight: 'bold', fontSize: 17, color: isDarkMode ? 'white' : 'black'}}>
                   {turma}
                </Text>
                <Text style={{ color: '#8A8A8A', fontWeight: 'bold', color: isDarkMode ? 'white' : 'black' }}>
                   {numero}
                </Text>
            </View>
            <Text style={[styles.subTexto, {color: isDarkMode ? 'white' : 'black'}]}>
                {alunos}
            </Text>
            <Text style={[styles.subTexto, {color: isDarkMode ? 'white' : 'black'}]}>
                {periodo}
            </Text>
            <View style={{alignItems: 'center', marginTop: 20}}>
            <TouchableOpacity  onPress={() => navigation.navigate(navegacao)} style={styles.botao} >
                <Text style={{color: 'white', fontWeight: 'bold'}}>
                    Visualizar Turma
                </Text>
            </TouchableOpacity>
            </View>
        </View>
    )
}
const styles = StyleSheet.create({
    card: {
        backgroundColor: '#F0F7FF',
        width: '100%',
        padding: 10,
        borderRadius: 15,
        marginBottom: 40
    },
    botao: {
        backgroundColor: '#1A85FF',
        alignItems: 'center',
        width: 230,
        padding: 6,
        borderRadius: 8
    },
    subTexto: {
        fontWeight: 'bold'
    },
    linha: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 10
    }
})