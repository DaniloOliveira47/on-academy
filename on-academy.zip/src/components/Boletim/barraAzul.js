import React from 'react'
import { View } from 'react-native'

export default function BarraAzul() {
    return (
        <View style={{ position: 'absolute' }}>
            <View style={{
                position: 'absolute',
                borderWidth: 6,
                backgroundColor: '#0077FF',
                borderColor: '#0077FF',
                width: 100,
                marginLeft: 120,
                marginTop: 52
            }}>
            </View>
            <View style={{
                position: 'absolute',
                borderWidth: 6,
                backgroundColor: '#0077FF',
                borderColor: '#0077FF',
                width: 100,
                marginLeft: 120,
                marginTop: 125
            }}>

            </View>
            <View style={{
                position: 'absolute',
                borderWidth: 6,
                backgroundColor: '#0077FF',
                borderColor: '#0077FF',
                width: 100,
                marginLeft: 120,
                marginTop: 200
            }}>
            </View>
            <View style={{
                position: 'absolute',
                borderWidth: 6,
                backgroundColor: '#0077FF',
                borderColor: '#0077FF',
                width: 100,
                marginLeft: 120,
                marginTop: 276
            }}>
            </View>
            <View style={{
                position: 'absolute',
                borderWidth: 6,
                backgroundColor: '#0077FF',
                borderColor: '#0077FF',
                width: 100,
                marginLeft: 120,
                marginTop: 352
            }}>
            </View>
        </View>

    )
}
